# jc_hv_ks_subsidiary
 Jeronimo HV/KS more subsidiary signals
